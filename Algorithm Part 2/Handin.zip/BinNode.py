class BinNode:
    key = None
    left = None
    right = None

    #When the class is initialized, it sets the key value 
    def __init__(self, key):
        self.key = key